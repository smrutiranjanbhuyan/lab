public class Tree {

	private static class Node {
		private int value;
		private Node lChild;
		private Node rChild;
		// Nested Class Node other fields and methods.    
	}

	private Node root;
	// Outer Class Tree other fields and methods.
}