public class ArrayDemo {
	public static void main(String[] args) {
		int[] arr = new int[10];
		for (int i = 0; i < 10; i++) {
			arr[i] = i;
		}
		for (int i = 0; i < 10; i++) {
			System.out.print(arr[i] + " ");
		}
	}
}

// 0 1 2 3 4 5 6 7 8 9