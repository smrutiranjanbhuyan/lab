
public class Stringclass {

	public static void main(String[] args) {
		String str1 = "hello";
		String str2 = "hello";
		String str3 = "Hello";
		System.out.println("str1 equals str2 :" + str1.equals(str2));
		System.out.println("str1 equals str3 :" + str1.equals(str3));

	}
}
/*
str1 equals str2 :true
str1 equals str3 :false
*/
