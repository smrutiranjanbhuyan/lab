public class parkingLot {
	private Map<int,Space> unreservedMap;
    private Map<int,Space> reservedMap;

    public boolean reserveSpace(Space)
    {
        //It will find if there is space in the 
        //unreserved map 
        //If yes, then we will pick that element and 
        //put into the reserved map with the current time value.
    }

	public int unreserveSpace(Space)
    {
        // It will find the entry in reserve map 
        // if yes then we will pick that 
        // Element and put into the unreserved map. 
        // And return the charge units with the current time value.
    }
}
